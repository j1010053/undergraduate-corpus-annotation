"""Build the frozen sample into a standalone document and an offline PWA.

This command NEVER draws another sample. Run sample_corpora.py explicitly to do so.
No third-party packages are required.
"""
import hashlib
import json
import re
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSETS = ["precoding.webmanifest", "precoding-icon-192.png", "precoding-icon-512.png", "precoding-icon-180.png"]


def main():
    corpus = json.loads((ROOT / "corpus.json").read_text(encoding="utf-8"))
    manifest = json.loads((ROOT / "sampling_manifest.json").read_text(encoding="utf-8"))
    if corpus["sampling"] != manifest:
        raise ValueError("Corpus and sampling manifest differ; inspect before publishing.")
    ids = [r["id"] for r in corpus["records"]]
    if len(ids) != len(set(ids)) or len(ids) != manifest["selectedCount"]:
        raise ValueError("Sample record inventory is invalid.")
    template = (ROOT / "reviewer.template.html").read_text(encoding="utf-8")
    if template.count("__CORPUS_JSON__") != 1:
        raise ValueError("The template must have exactly one data placeholder.")
    payload = json.dumps(corpus, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    pwa = (ROOT / "pwa.js").read_text(encoding="utf-8")
    worker = (ROOT / "precoding-sw.template.js").read_text(encoding="utf-8")
    # Content-derived version: rebuilding identical inputs does not replace the cache.
    version_hash = hashlib.sha256()
    for part in [template.encode(), payload.encode(), pwa.encode(), worker.encode(),
                 *[(ROOT / name).read_bytes() for name in ASSETS]]:
        version_hash.update(len(part).to_bytes(8, "big"))
        version_hash.update(part)
    version = version_hash.hexdigest()[:16]
    if template.count("__PWA_JS__") != 1:
        raise ValueError("Expected exactly one PWA code placeholder.")
    html = template.replace("__CORPUS_JSON__", payload).replace("__PWA_JS__", pwa).replace("__PWA_VERSION__", version)
    dist, qa = ROOT / "dist", ROOT / "qa"
    dist.mkdir(exist_ok=True)
    qa.mkdir(exist_ok=True)
    (dist / "precoding.html").write_text(html, encoding="utf-8")
    (dist / "precoding-sw.js").write_text(worker.replace("__PWA_VERSION__", version), encoding="utf-8")
    for name in ASSETS:
        shutil.copyfile(ROOT / name, dist / name)
    for src, dest in (("sampling_manifest.json", "precoding-sampling-manifest.json"),
                      ("source_audit.json", "precoding-source-audit.json"),
                      ("README.md", "precoding-methods.md")):
        shutil.copyfile(ROOT / src, dist / dest)
    scripts = re.findall(r"<script>([\s\S]*?)</script>", html)
    if len(scripts) != 1:
        raise ValueError("Expected one inline app script.")
    (qa / "app-syntax.js").write_text(scripts[0], encoding="utf-8")
    # Source archive contains ONLY the sampled corpus, never unsampled raw exports.
    names = ["sampling_config.json", "sample_corpora.py", "source_alignment.py", "build.py",
             "verify_sample.py", "reviewer.template.html", "corpus.json", "sampling_manifest.json",
             "source_audit.json", "README.md", "pwa.js", "precoding-sw.template.js", "make_icons.py", *ASSETS]
    with zipfile.ZipFile(dist / "precoding-source.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for name in names:
            archive.write(ROOT / name, "concordance-precoding-site/" + name)
        archive.write(dist / "precoding.html", "concordance-precoding-site/dist/precoding.html")
        archive.write(dist / "precoding-sw.js", "concordance-precoding-site/dist/precoding-sw.js")
        for name in ASSETS:
            archive.write(dist / name, "concordance-precoding-site/dist/" + name)
    report = {"datasetId": corpus["id"], "seed": manifest["seed"], "records": len(ids),
              "pwaVersion": version,
              "htmlSha256": hashlib.sha256((dist / "precoding.html").read_bytes()).hexdigest(),
              "deployFiles": [p.name for p in sorted(dist.iterdir()) if p.is_file()]}
    (ROOT / "build_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
