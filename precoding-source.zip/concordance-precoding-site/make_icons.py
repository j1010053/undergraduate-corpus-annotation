"""Generate the simple book/check app icon with standard-library PNG encoding."""
import struct
import zlib
from pathlib import Path


def chunk(name, data):
    return struct.pack(">I", len(data)) + name + data + struct.pack(">I", zlib.crc32(name + data))


def icon(size):
    green, paper, gold = (38, 92, 71), (255, 254, 250), (248, 228, 182)
    rows = bytearray()
    for y in range(size):
        rows.append(0)
        for x in range(size):
            u, v = x / size, y / size
            color = green
            if .24 <= u <= .76 and .23 <= v <= .77:
                color = paper
            if .31 <= u <= .67 and any(a <= v <= a + .026 for a in [.33, .43]):
                color = green
            # Two joined strokes form a check, inside the maskable safe zone.
            if .34 <= u <= .45 and abs(v - (.57 + .75 * (u - .34))) < .021:
                color = green
            if .43 <= u <= .65 and abs(v - (.65 - .7 * (u - .45))) < .021:
                color = green
            if .24 <= u <= .76 and .75 <= v <= .79:
                color = gold
            rows.extend(color)
    return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(bytes(rows), 9)) + chunk(b"IEND", b"")


if __name__ == "__main__":
    for size in [180, 192, 512]:
        (Path(__file__).parent / f"precoding-icon-{size}.png").write_bytes(icon(size))
