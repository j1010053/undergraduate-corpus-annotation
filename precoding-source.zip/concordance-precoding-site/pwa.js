// Compiled inline so downloaded annotated HTML remains self-contained.
const APP_VERSION = "__PWA_VERSION__";
let swRegistration = null, installPrompt = null, reloadForUpdate = false;
const standalone = () => matchMedia("(display-mode: standalone)").matches || navigator.standalone === true;
const onlinePage = ["http:","https:"].includes(location.protocol);
function installationUI(){
  $("install-app").hidden = !installPrompt || standalone();
  if(standalone()) $("install-hint").textContent = "目前已在獨立視窗中使用，可由桌面／主畫面再次開啟。";
}
function connectionUI(){ $("offline-connection").textContent = "裝置連線狀態：" + (navigator.onLine ? "連線中" : "離線"); }
function offlineStatus(message,ready=false){
  $("offline-status").textContent = message;
  $("offline-btn").textContent = ready ? "離線使用 ✓" : "離線使用";
  $("offline-btn").dataset.ready = String(ready);
}
function workerStatus(worker){
  return new Promise((resolve,reject)=>{
    const channel = new MessageChannel();
    const timer = setTimeout(()=>{channel.port1.close();reject(new Error("快取檢查逾時"));},5000);
    channel.port1.onmessage = event => {clearTimeout(timer);channel.port1.close();resolve(event.data);};
    worker.postMessage({type:"CACHE_STATUS"},[channel.port2]);
  });
}
async function refreshOfflineStatus(){
  connectionUI();installationUI();
  if(!swRegistration?.active) return;
  $("apply-update").hidden = !swRegistration.waiting;
  try {
    const result = await workerStatus(swRegistration.active);
    const controlled = navigator.serviceWorker.controller?.scriptURL === new URL("precoding-sw.js",location.href).href;
    if(result.ready && controlled){
      offlineStatus("離線已就緒："+records.length+" 筆語料、完整語境與標註工具已保存在此瀏覽器。",true);
      $("offline-version").textContent = "網站版本 " + APP_VERSION + (swRegistration.waiting ? " · 有新版本可套用" : "");
    } else {
      offlineStatus(controlled ? "離線快取不完整，請保持連線並重新整理；也可匯出含標註的離線網頁。" : "快取已準備，正在啟用離線功能；若尚未完成，請重新整理一次。");
    }
  } catch(_) {offlineStatus("目前無法確認離線快取，請連網後再檢查；標註仍按原方式保存在本機。");}
}
async function storageStatus(){
  if(!onlinePage || !navigator.storage?.persisted){
    $("persistent-status").textContent = "此環境不支援持續儲存請求；請用 JSON 或含標註的離線網頁備份。";
    $("persist-storage").hidden = true;return;
  }
  try {
    const granted = await navigator.storage.persisted();
    $("persistent-status").textContent = granted ? "瀏覽器已允許持續儲存，可降低空間不足時自動清除資料的風險；手動清除網站資料仍會移除標註。" : "目前使用一般本機儲存。可請求持續儲存，是否允許由瀏覽器決定；未獲准仍能標註與離線使用。";
    $("persist-storage").hidden = granted || !navigator.storage.persist;
  } catch(_) {$("persistent-status").textContent = "無法確認持續儲存狀態，請定期匯出備份。";$("persist-storage").hidden=true;}
}
function watchInstallation(worker){
  if(!worker)return;
  worker.addEventListener("statechange",()=>{
    if(worker.state === "installed" || worker.state === "activated") refreshOfflineStatus();
    if(worker.state === "redundant") {
      if(swRegistration?.active){refreshOfflineStatus();toast("新版下載未完成，目前的離線版本仍可使用。");}
      else offlineStatus("離線快取未完成。請確認連線後按「檢查快取與更新」重試。");
    }
  });
}
async function setupOffline(){
  connectionUI();installationUI();
  $("apply-update").hidden = true;
  $("offline-version").textContent = "網站版本 " + APP_VERSION;
  if(!onlinePage){
    offlineStatus("目前是下載的離線網頁，可直接閱讀與標註；PWA 安裝請回到線上網址。");
    $("check-offline").disabled = true;return;
  }
  if(!isSecureContext || !("serviceWorker" in navigator)){
    offlineStatus("此瀏覽器無法啟用 PWA；請用一般瀏覽器開啟 HTTPS 網址，或匯出含標註的離線網頁。");
    $("check-offline").disabled = true;return;
  }
  try {
    swRegistration = await navigator.serviceWorker.register("./precoding-sw.js",{scope:"./",updateViaCache:"none"});
    swRegistration.addEventListener("updatefound",()=>watchInstallation(swRegistration.installing));
    watchInstallation(swRegistration.installing);
    await refreshOfflineStatus();
  } catch(_) {offlineStatus("離線快取尚未建立。請確認網路連線，再按「檢查快取與更新」重試。");}
}
window.addEventListener("beforeinstallprompt",event=>{event.preventDefault();installPrompt=event;installationUI();});
window.addEventListener("appinstalled",()=>{installPrompt=null;installationUI();toast("已安裝，可從桌面或主畫面再次開啟。");});
window.addEventListener("online",refreshOfflineStatus);
window.addEventListener("offline",refreshOfflineStatus);
if("serviceWorker" in navigator) navigator.serviceWorker.addEventListener("controllerchange",()=>{
  if(reloadForUpdate){reloadForUpdate=false;location.reload();}else refreshOfflineStatus();
});
$("offline-btn").onclick=()=>{$("offline-dialog").showModal();refreshOfflineStatus();storageStatus();};
$("install-app").onclick=async()=>{
  if(!installPrompt)return;
  const prompt=installPrompt;installPrompt=null;installationUI();
  try {await prompt.prompt();await prompt.userChoice;}catch(_){toast("請改用瀏覽器選單的安裝功能。");}
};
$("persist-storage").onclick=async()=>{
  try {const granted=await navigator.storage.persist();await storageStatus();toast(granted?"已獲准持續儲存。仍建議定期匯出備份。":"瀏覽器尚未允許持續儲存，仍可正常使用；請定期匯出備份。");}
  catch(_){toast("此瀏覽器無法完成請求，請使用 JSON 備份。");}
};
$("check-offline").onclick=async()=>{
  $("check-offline").disabled=true;
  try {
    if(!swRegistration) await setupOffline();
    else {await swRegistration.update();await refreshOfflineStatus();toast(swRegistration.waiting?"新版本已下載，可按「套用更新並重新開啟」。":"已檢查；離線準備狀態顯示於上方。");}
  }catch(_){await refreshOfflineStatus();toast("目前無法連線檢查更新；已備妥的離線快取仍可使用。");}
  finally {$("check-offline").disabled=!onlinePage || !isSecureContext || !("serviceWorker" in navigator);}
};
$("apply-update").onclick=()=>{
  // Flush pending tag text and the current annotation before any user-requested reload.
  addTag($("tag-input").value);
  if(!persist() || !storageOK){toast("本機保存未成功，請先匯出 JSON 備份再更新。");return;}
  if(swRegistration?.waiting){reloadForUpdate=true;swRegistration.waiting.postMessage({type:"SKIP_WAITING"});}
};
setupOffline();storageStatus();
