"""Independent replay against original source files; no sampler functions used."""
import csv
import hashlib
import json
import random
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def main():
    read=lambda p:json.loads((ROOT/p).read_text(encoding="utf-8"))
    corpus,manifest,cfg=read("corpus.json"),read("sampling_manifest.json"),read("sampling_config.json")
    baseline=read(cfg["baseline"])
    assert corpus["sampling"]==manifest and manifest["seed"]==20261024
    assert [g["populationCount"] for g in manifest["groups"]]==[586,24,3997,618]
    assert [g["selectedCount"] for g in manifest["groups"]]==[15,15,15,15]
    assert manifest["selectedCount"]==len(corpus["records"])==60
    assert [r["sampleNumber"] for r in corpus["records"]]==list(range(1,61))
    current={r["id"]:r for r in corpus["records"]}
    assert len(current)==60
    for old in baseline["records"]:
        assert {k:v for k,v in old.items() if k!="sampleNumber"}=={k:v for k,v in current[old["id"]].items() if k!="sampleNumber"}
    assert corpus["compatibleDatasets"]==[{"id":baseline["id"],"recordIds":[r["id"] for r in baseline["records"]]}]
    comparisons=0
    for group in manifest["groups"]:
        pool,raw_by_key,seen=[],{},set()
        for source in group["sources"]:
            path=ROOT.parent/source["source"]
            assert hashlib.sha256(path.read_bytes()).hexdigest()==source["sha256"]
            with path.open(encoding="utf-8-sig",newline="") as f:raw=list(csv.DictReader(f,delimiter="\t",quoting=csv.QUOTE_NONE))
            assert len(raw)==source["rows"]
            for r in sorted(raw,key=lambda r:int(r["Number of hit"])):
                item=(source["source"],int(r["Number of hit"]))
                key=(r["Text ID"],int(r["Match-begin corpus position"]),int(r["Match-end corpus position"]),"".join(r["Query item"].split()))
                raw_by_key[item]=r
                if key not in seen:seen.add(key);pool.append(item)
        retained=[(r["sourceFile"],r["hit"]) for r in baseline["records"] if r["groupId"]==group["id"]]
        candidates=[item for item in pool if item not in retained]
        seed=int(hashlib.sha256(f"20261024|{group['id']}".encode()).hexdigest(),16)
        expected=random.Random(seed).sample(candidates,15-len(retained))
        assert expected==[(d["sourceFile"],d["sourceHit"]) for d in group["drawOrderSourceRecords"]]
        selected=[r for r in corpus["records"] if r["groupId"]==group["id"]]
        assert {(r["sourceFile"],r["hit"]) for r in selected}==set(retained+expected)
        for r in selected:
            original=raw_by_key[(r["sourceFile"],r["hit"])]
            assert r["textId"]==original["Text ID"] and r["query"]==original["Query item"]
            assert r["begin"]==int(original["Match-begin corpus position"]) and r["end"]==int(original["Match-end corpus position"])
            for prop,field in [("before","Context before"),("after","Context after"),("taggedBefore","Tagged context before"),("taggedAfter","Tagged context after"),("taggedQuery","Tagged query item")]:
                assert r["contexts"]["long"][prop]==original[field];comparisons+=1
            for mode,size in [("short",10),("medium",40)]:
                assert r["contexts"][mode]["before"].split()==original["Context before"].split()[-size:]
                assert r["contexts"][mode]["after"].split()==original["Context after"].split()[:size]
    result={"passed":True,"records":60,"retained":35,"added":25,"seed":20261024,"fullSourceFieldComparisons":comparisons}
    (ROOT/"qa/extension-verification.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,ensure_ascii=False))


if __name__=="__main__":main()
