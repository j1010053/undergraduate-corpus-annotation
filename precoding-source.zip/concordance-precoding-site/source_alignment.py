"""Align original POS annotations to original untagged whitespace tokens.

No retagging or last-underscore split. The exact plain token is the prefix:
有 + "_" + V_2 is valid, as is Oliver_Cromwell + "_" + FW.
Only source artifacts with an empty surface ("_", "_FW") may be removed,
and only when the whole field then matches one-to-one, in order.
Bare tokens retain POS=None. Any other mismatch stops the analysis.
"""

FIELDS = [
    ("Context before", "Tagged context before"),
    ("Query item", "Tagged query item"),
    ("Context after", "Tagged context after"),
]
EMPTY_SURFACE_ARTIFACTS = {"_", "_FW"}


def pair_matches(word, tagged):
    return tagged == word or tagged.startswith(word + "_")


def align_field(plain_text, tagged_text):
    words, tagged = plain_text.split(), tagged_text.split()
    indexed = list(enumerate(tagged))
    removed = []
    if len(words) != len(tagged):
        # A proposed correction is accepted only after exact whole-field
        # surface validation. This cannot silently shift subsequent tags.
        indexed = [(i, text) for i, text in indexed if text not in EMPTY_SURFACE_ARTIFACTS]
        removed = [{"tagged_index": i, "raw_tagged": text, "reason": "empty_surface_artifact"}
                   for i, text in enumerate(tagged) if text in EMPTY_SURFACE_ARTIFACTS]
    if len(words) != len(indexed) or not all(
        pair_matches(word, text) for word, (_, text) in zip(words, indexed)
    ):
        raise ValueError("POS alignment is not exact; inspect source instead of guessing tags.")
    records = []
    for index, (word, (tagged_index, text)) in enumerate(zip(words, indexed)):
        suffix = text[len(word) + 1:] if text.startswith(word + "_") else ""
        records.append({
            "field_token_index": index, "word": word,
            "pos": suffix or None, "raw_tagged": text,
            "tagged_index": tagged_index,
            "alignment_status": "exact" if suffix else "missing_pos",
        })
    return records, removed


def align_row(row):
    aligned, events = [], []
    for plain, tagged in FIELDS:
        records, removed = align_field(row[plain], row[tagged])
        offset = len(aligned)
        for item in records:
            record = {**item, "field": plain, "token_index": offset + item["field_token_index"]}
            aligned.append(record)
            if record["pos"] is None:
                events.append({**record, "reason": "missing_pos"})
        events.extend({**item, "field": plain} for item in removed)
    return aligned, events
