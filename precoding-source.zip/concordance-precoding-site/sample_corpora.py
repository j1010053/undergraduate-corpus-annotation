"""Audit CQP exports and draw reproducible samples; no linguistic classification.

Run: python sample_corpora.py
Sampling unit: original query hit, NOT document or sentence.
Independent PRNG per group; Python Random.sample without replacement.
Keep every hit when population <= configured sample size.
"""
import csv
import hashlib
import json
import platform
import random
from pathlib import Path

from source_alignment import align_field

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
COLUMNS = ["Number of hit", "Text ID", "Context before", "Query item", "Context after",
           "Tagged context before", "Tagged query item", "Tagged context after", "URL",
           "Match-begin corpus position", "Match-end corpus position"]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def identity(row):
    return [row[k] for k in ("Text ID", "Match-begin corpus position",
                             "Match-end corpus position", "Query item")]


def read_source(name):
    path = WORKSPACE / name
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t", quoting=csv.QUOTE_NONE)
        if reader.fieldnames != COLUMNS:
            raise ValueError(f"Unexpected header: {name}")
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError(f"Malformed TSV: {name}")
    rows.sort(key=lambda r: int(r["Number of hit"]))
    if [int(r["Number of hit"]) for r in rows] != list(range(1, len(rows) + 1)):
        raise ValueError(f"Nonconsecutive source hit numbers: {name}")
    if len({tuple(identity(r)) for r in rows}) != len(rows):
        raise ValueError(f"Duplicate hit identities: {name}")
    return rows, digest(path.read_bytes())


def group_seed(seed, group_id):
    material = f"{seed}|{group_id}"
    hex_value = digest(material.encode("utf-8"))
    return int(hex_value, 16), material, hex_value


def select_rows(rows, seed, group_id, size):
    ordered = sorted(rows, key=lambda r: int(r["Number of hit"]))
    if len(ordered) <= size:
        return ordered, [int(r["Number of hit"]) for r in ordered]
    derived, _, _ = group_seed(seed, group_id)
    drawn = random.Random(derived).sample(ordered, size)
    return sorted(drawn, key=lambda r: int(r["Number of hit"])), [int(r["Number of hit"]) for r in drawn]


def contexts(row):
    paired = {}
    for field in ("Context before", "Query item", "Context after"):
        paired[field], _ = align_field(row[field], row["Tagged " + field.lower()])
    out = {}
    for name, limit in (("short", 10), ("medium", 40), ("long", None)):
        if limit is None:
            out[name] = {"before": row["Context before"], "after": row["Context after"],
                         "taggedBefore": row["Tagged context before"],
                         "taggedQuery": row["Tagged query item"], "taggedAfter": row["Tagged context after"]}
        else:
            before, after = paired["Context before"][-limit:], paired["Context after"][:limit]
            out[name] = {"before": " ".join(t["word"] for t in before),
                         "after": " ".join(t["word"] for t in after),
                         "taggedBefore": " ".join(t["raw_tagged"] for t in before),
                         "taggedQuery": row["Tagged query item"],
                         "taggedAfter": " ".join(t["raw_tagged"] for t in after)}
    return out


def run():
    config = json.loads((ROOT / "sampling_config.json").read_text(encoding="utf-8"))
    if config.get("mode") == "retain_and_topup":
        from extend_sample import run as extend
        return extend()
    seed, size = config["seed"], config["sample_size_per_group"]
    if not isinstance(seed, int) or not isinstance(size, int) or size <= 0:
        raise ValueError("Seed must be an integer and sample size must be positive.")
    records, group_reports, source_audit = [], [], []
    for group in config["groups"]:
        rows, sha = read_source(group["source"])
        if len(rows) != group["expected_count"]:
            raise ValueError(f"Source count changed for {group['source']}; inspect and update config explicitly.")
        if any("".join(r["Query item"].split()) != group["expression"] for r in rows):
            raise ValueError(f"Unexpected target: {group['source']}")
        events = []
        for row in rows:
            for field in ("Context before", "Query item", "Context after"):
                aligned, removed = align_field(row[field], row["Tagged " + field.lower()])
                events.extend({"hit": int(row["Number of hit"]), "field": field, **e} for e in removed)
                events.extend({"hit": int(row["Number of hit"]), "field": field,
                               "reason": "missing_pos", "word": t["word"]} for t in aligned if t["pos"] is None)
        aliases = []
        for name in group.get("equivalent_exports", []):
            alias_rows, alias_sha = read_source(name)
            if [identity(r) for r in rows] != [identity(r) for r in alias_rows]:
                raise ValueError(f"Equivalent export no longer matches: {name}")
            aliases.append({"source": name, "sha256": alias_sha, "rows": len(alias_rows),
                            "same_hit_inventory": True, "added_to_population": False})
        selected, draw_order = select_rows(rows, seed, group["id"], size)
        _, seed_material, seed_hex = group_seed(seed, group["id"])
        group_records = []
        for row in selected:
            stable = json.dumps([group["id"], *identity(row)], ensure_ascii=False, separators=(",", ":"))
            item = {"id": "pc-" + group["id"] + "-" + digest(stable.encode("utf-8"))[:20],
                    "sampleNumber": len(records) + 1, "hit": int(row["Number of hit"]),
                    "groupId": group["id"], "groupLabel": group["label"], "register": group["register"],
                    "expression": group["expression"], "sourceFile": group["source"], "sourceSha256": sha,
                    "textId": row["Text ID"], "year": row["Text ID"][:4], "query": row["Query item"],
                    "begin": int(row["Match-begin corpus position"]), "end": int(row["Match-end corpus position"]),
                    "url": row["URL"], "contexts": contexts(row)}
            records.append(item)
            group_records.append({k: item[k] for k in ("id", "sampleNumber", "hit", "textId", "begin", "end")})
        group_reports.append({"id": group["id"], "label": group["label"], "source": group["source"],
                              "sourceSha256": sha, "populationCount": len(rows), "selectedCount": len(selected),
                              "selection": "all" if len(rows) <= size else "random_without_replacement",
                              "seedMaterial": seed_material, "derivedSeedSha256": seed_hex,
                              "drawOrderSourceHits": draw_order, "displayOrderSourceHits": [r["hit"] for r in group_records],
                              "records": group_records})
        source_audit.append({"source": group["source"], "sha256": sha, "rows": len(rows),
                             "textIds": len({r["Text ID"] for r in rows}), "alignmentEvents": events,
                             "equivalentExports": aliases})
    manifest = {"version": 1, "seed": seed, "sampleSizePerGroup": size, "pythonVersion": platform.python_version(),
                "samplingUnit": "original query hit; different hits in one document remain eligible",
                "method": "Each group: sort by original hit number; seed = int(SHA256(UTF8(str(seed)+'|'+groupId)),16); Python random.Random(seed).sample(rows,15) without replacement; retain all when N<=15.",
                "displayOrder": "configuration group order, then original hit number; browser reload never resamples",
                "groupSeedIndependence": True, "populationCount": sum(g["populationCount"] for g in group_reports),
                "selectedCount": len(records), "groups": group_reports}
    identity_material = {"seed": seed, "size": size, "groups": group_reports}
    dataset_id = "precoding-" + str(seed) + "-" + digest(json.dumps(identity_material, sort_keys=True, ensure_ascii=False).encode("utf-8"))[:16]
    manifest["datasetId"] = dataset_id
    corpus = {"id": dataset_id, "title": "來說句式 · Pre-coding", "sampling": manifest,
              "contextLabels": {"short": "前後各 10 個原始斷詞單位", "medium": "前後各 40 個原始斷詞單位", "long": "完整匯出語境"},
              "records": records}
    write_json("source_audit.json", {"sources": source_audit, "populationCount": manifest["populationCount"]})
    write_json("sampling_manifest.json", manifest)
    write_json("corpus.json", corpus)
    print(json.dumps({"datasetId": dataset_id, "seed": seed, "groups": [{"label": g["label"], "population": g["populationCount"], "sample": g["selectedCount"], "hits": g["displayOrderSourceHits"]} for g in group_reports]}, ensure_ascii=False))
    return corpus


if __name__ == "__main__":
    run()
