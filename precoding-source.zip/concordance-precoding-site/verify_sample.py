"""Independent data-integrity and reproducibility checks against the raw exports."""
import csv
import hashlib
import json
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    corpus = json.loads((ROOT / "corpus.json").read_text(encoding="utf-8"))
    manifest = json.loads((ROOT / "sampling_manifest.json").read_text(encoding="utf-8"))
    assert corpus["sampling"] == manifest
    assert manifest["selectedCount"] == 35
    assert [g["populationCount"] for g in manifest["groups"]] == [586, 24, 3, 2]
    assert [g["selectedCount"] for g in manifest["groups"]] == [15, 15, 3, 2]
    assert [r["sampleNumber"] for r in corpus["records"]] == list(range(1, 36))
    assert len({r["id"] for r in corpus["records"]}) == 35
    comparisons = 0
    for group in manifest["groups"]:
        source = ROOT.parent / group["source"]
        assert hashlib.sha256(source.read_bytes()).hexdigest() == group["sourceSha256"]
        with source.open(encoding="utf-8-sig", newline="") as f:
            raw = list(csv.DictReader(f, delimiter="\t", quoting=csv.QUOTE_NONE))
        raw.sort(key=lambda r: int(r["Number of hit"]))
        derived = int(hashlib.sha256(f"{manifest['seed']}|{group['id']}".encode()).hexdigest(), 16)
        if len(raw) > 15:
            expected = random.Random(derived).sample(list(range(1, len(raw) + 1)), 15)
        else:
            expected = list(range(1, len(raw) + 1))
        assert expected == group["drawOrderSourceHits"]
        assert sorted(expected) == group["displayOrderSourceHits"]
        items = [r for r in corpus["records"] if r["groupId"] == group["id"]]
        assert [r["hit"] for r in items] == sorted(expected)
        for r in items:
            original = raw[r["hit"] - 1]
            assert r["textId"] == original["Text ID"]
            assert r["begin"] == int(original["Match-begin corpus position"])
            assert r["end"] == int(original["Match-end corpus position"])
            assert r["query"] == original["Query item"]
            for prop, field in (("before", "Context before"), ("after", "Context after"),
                                ("taggedBefore", "Tagged context before"), ("taggedAfter", "Tagged context after"),
                                ("taggedQuery", "Tagged query item")):
                assert r["contexts"]["long"][prop] == original[field]
                comparisons += 1
            for mode, size in (("short", 10), ("medium", 40)):
                assert r["contexts"][mode]["before"].split() == original["Context before"].split()[-size:]
                assert r["contexts"][mode]["after"].split() == original["Context after"].split()[:size]
    # Group membership is part of identity: original hit #1 in three groups cannot collide.
    ones = [r["id"] for r in corpus["records"] if r["hit"] == 1]
    assert len(ones) == len(set(ones)) == 3
    print(json.dumps({"passed": True, "sampleCount": 35, "fullSourceFieldComparisons": comparisons,
                      "checks": ["four group counts", "seed replay", "source hashes", "unique identities",
                                 "original hit mapping", "unaltered full context and POS", "preview token boundaries"]}))


if __name__ == "__main__":
    main()
