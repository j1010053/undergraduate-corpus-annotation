"""Retain frozen hits and sample only the shortfall, independently by group.

This is a retained-sample extension, NOT a fresh simple random sample of all hits.
It never reads browser annotations. Stable record IDs allow the UI to migrate them.
"""
import copy
import json
import platform
import random
from sample_corpora import ROOT, read_source, identity, digest, group_seed, contexts, write_json
from source_alignment import align_field


def canonical(row):
    return (row["Text ID"],int(row["Match-begin corpus position"]),int(row["Match-end corpus position"]),"".join(row["Query item"].split()))


def run():
    cfg=json.loads((ROOT/"sampling_config.json").read_text(encoding="utf-8"))
    baseline=json.loads((ROOT/cfg["baseline"]).read_text(encoding="utf-8"))
    seed,size=cfg["seed"],cfg["sample_size_per_group"]
    if seed != baseline["sampling"]["seed"]: raise ValueError("This extension retains the original seed")
    records,reports,audits=[],[],[]
    for group in cfg["groups"]:
        sources=[{"file":group["source"],"expected_count":group["expected_count"]},*group.get("additional_sources",[])]
        pool,seen,source_reports=[],set(),[]
        for source in sources:
            rows,sha=read_source(source["file"])
            if len(rows)!=source["expected_count"]: raise ValueError("Source size changed: "+source["file"])
            events=[]
            for row in rows:
                if "".join(row["Query item"].split())!=group["expression"]:raise ValueError("Unexpected target")
                for field in ("Context before","Query item","Context after"):
                    aligned,removed=align_field(row[field],row["Tagged "+field.lower()])
                    events.extend({"hit":int(row["Number of hit"]),"field":field,**e} for e in removed)
                    events.extend({"hit":int(row["Number of hit"]),"field":field,"reason":"missing_pos","word":t["word"]} for t in aligned if t["pos"] is None)
                key=canonical(row)
                if key not in seen:
                    seen.add(key);pool.append((source["file"],sha,row))
            source_reports.append({"source":source["file"],"sha256":sha,"rows":len(rows)})
            audits.append({"source":source["file"],"sha256":sha,"rows":len(rows),"alignmentEvents":events})
        retained=copy.deepcopy([r for r in baseline["records"] if r["groupId"]==group["id"]])
        oldkeys={(r["textId"],r["begin"],r["end"],"".join(r["query"].split())) for r in retained}
        if not oldkeys.issubset(seen):raise ValueError("A retained hit disappeared")
        candidates=[entry for entry in pool if canonical(entry[2]) not in oldkeys]
        needed=min(size,len(pool))-len(retained)
        if needed<0:raise ValueError("Requested size is smaller than retained sample")
        derived,material,seed_hex=group_seed(seed,group["id"])
        drawn=random.Random(derived).sample(candidates,needed) if needed else []
        additions=[]
        for source,sha,row in drawn:
            stable=json.dumps([group["id"],*identity(row)],ensure_ascii=False,separators=(",",":"))
            additions.append({"id":"pc-"+group["id"]+"-"+digest(stable.encode("utf-8"))[:20],
              "sampleNumber":0,"hit":int(row["Number of hit"]),"groupId":group["id"],"groupLabel":group["label"],
              "register":group["register"],"expression":group["expression"],"sourceFile":source,"sourceSha256":sha,
              "textId":row["Text ID"],"year":row["Text ID"][:4],"query":row["Query item"],
              "begin":int(row["Match-begin corpus position"]),"end":int(row["Match-end corpus position"]),
              "url":row["URL"],"contexts":contexts(row)})
        order={s["file"]:i for i,s in enumerate(sources)}
        selected=sorted(retained+additions,key=lambda r:(order[r["sourceFile"]],r["hit"]))
        for r in selected:r["sampleNumber"]=len(records)+1;records.append(r)
        reports.append({"id":group["id"],"label":group["label"],"sources":source_reports,
          "populationCount":len(pool),"selectedCount":len(selected),"retainedCount":len(retained),"addedCount":len(additions),
          "candidateCount":len(candidates),"selection":"retained_and_random_topup" if needed else "retained_frozen_sample",
          "seedMaterial":material,"derivedSeedSha256":seed_hex,"retainedRecordIds":[r["id"] for r in retained],
          "drawOrderSourceRecords":[{"sourceFile":s,"sourceHit":int(r["Number of hit"])} for s,_,r in drawn],
          "displayOrderSourceHits":[r["hit"] for r in selected],
          "records":[{k:r[k] for k in ["id","sampleNumber","hit","sourceFile","textId","begin","end"]} for r in selected]})
    material={"seed":seed,"baseline":baseline["id"],"groups":reports}
    dataset_id="precoding-"+str(seed)+"-"+digest(json.dumps(material,sort_keys=True,ensure_ascii=False).encode())[:16]
    manifest={"version":2,"datasetId":dataset_id,"seed":seed,"sampleSizePerGroup":size,"pythonVersion":platform.python_version(),
      "samplingUnit":"original query hit; deduplicate within register by TextID + begin + end + normalized query",
      "method":"Retain baseline sample; concatenate sources in config order and sort by original hit; remove already selected identities; sample the shortfall without replacement with int(SHA256(UTF8(str(seed)+'|'+groupId)),16).",
      "displayOrder":"group, source order, original hit; S numbers may shift, stable IDs never shift",
      "baselineDatasetId":baseline["id"],"baselineSha256":digest((ROOT/cfg["baseline"]).read_bytes()),
      "groupSeedIndependence":True,"populationCount":sum(g["populationCount"] for g in reports),"selectedCount":len(records),"groups":reports}
    corpus={"id":dataset_id,"title":baseline["title"],"sampling":manifest,"contextLabels":baseline["contextLabels"],"records":records,
      "compatibleDatasets":[{"id":baseline["id"],"recordIds":[r["id"] for r in baseline["records"]]}]}
    current={r["id"]:r for r in records}
    for old in baseline["records"]:
        if {k:v for k,v in old.items() if k!="sampleNumber"}!={k:v for k,v in current[old["id"]].items() if k!="sampleNumber"}:
            raise ValueError("Retained source content changed; migration is not safe")
    write_json("corpus.json",corpus);write_json("sampling_manifest.json",manifest)
    write_json("source_audit.json",{"sources":audits,"populationCount":manifest["populationCount"],"baselineDatasetId":baseline["id"],"retainedContentUnchanged":True})
    print(json.dumps({"datasetId":dataset_id,"seed":seed,"records":len(records),"groups":[{"id":g["id"],"population":g["populationCount"],"retained":g["retainedCount"],"added":g["addedCount"],"draw":g["drawOrderSourceRecords"]} for g in reports]},ensure_ascii=False))
    return corpus


if __name__=="__main__":run()
